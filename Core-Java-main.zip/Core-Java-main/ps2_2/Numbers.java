package ps2_2;

public class Numbers {

}

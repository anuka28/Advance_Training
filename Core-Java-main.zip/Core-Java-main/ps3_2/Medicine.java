package ps3_2;

public class Medicine {

}

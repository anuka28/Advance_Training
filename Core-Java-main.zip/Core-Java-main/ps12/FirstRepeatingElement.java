package ps12;

public class FirstRepeatingElement {

}

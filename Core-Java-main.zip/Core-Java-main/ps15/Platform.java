package ps15;

public class Platform {

}

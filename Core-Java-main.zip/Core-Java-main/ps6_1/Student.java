package ps6_1;

public class Student {

}

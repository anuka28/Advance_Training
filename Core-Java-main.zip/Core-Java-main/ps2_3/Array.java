package ps2_3;

public class Array {

}

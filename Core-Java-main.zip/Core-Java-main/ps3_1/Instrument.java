package ps3_1;

public class Instrument {

}

package ps2_1;

public class Strings {

}

package ps7_1;

public class FileCopy {

}

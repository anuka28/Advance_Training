package ps5_2;

public class SplitMethod {

}

package ps7_2;

public class StudentDemo {

}

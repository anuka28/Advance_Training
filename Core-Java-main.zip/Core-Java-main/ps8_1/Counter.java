package ps8_1;

public class Counter {

}

package ps1_2;

public class TestRectangle {

}

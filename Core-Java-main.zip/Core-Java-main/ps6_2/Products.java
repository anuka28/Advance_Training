package ps6_2;

public class Products {

}

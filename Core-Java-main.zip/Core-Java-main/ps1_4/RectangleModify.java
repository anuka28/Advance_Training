package ps1_4;

public class RectangleModify {

}

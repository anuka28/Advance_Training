package ps9;

public class ArrayFrequency {

}

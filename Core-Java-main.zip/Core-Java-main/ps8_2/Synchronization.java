package ps8_2;

public class Synchronization {

}
